export class HotelInfo {
    constructor()
    {
        this.HotelName="";
        this.Rooms=1;
        this.RoomType="";
        this.Address="";
        this.Email="";
    }

    public HotelName:string;
    public Rooms:number;
    public RoomType:string;
    public Address:string;
    public Email:string;
}
