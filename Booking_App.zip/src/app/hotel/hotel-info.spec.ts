import { HotelInfo } from './hotel-info';

describe('HotelInfo', () => {
  it('should create an instance', () => {
    expect(new HotelInfo()).toBeTruthy();
  });
});
